﻿namespace csharpprojrctfinal
{
	partial class Alllogin
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			button2 = new Button();
			adlog = new Button();
			textBox2 = new TextBox();
			textBox1 = new TextBox();
			label2 = new Label();
			label1 = new Label();
			button1 = new Button();
			pictureBox1 = new PictureBox();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			// 
			// button2
			// 
			button2.Location = new Point(694, 409);
			button2.Name = "button2";
			button2.Size = new Size(94, 29);
			button2.TabIndex = 11;
			button2.Text = "Back";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// adlog
			// 
			adlog.Location = new Point(694, 241);
			adlog.Name = "adlog";
			adlog.Size = new Size(94, 29);
			adlog.TabIndex = 10;
			adlog.Text = "Login";
			adlog.UseVisualStyleBackColor = true;
			adlog.Click += adlog_Click;
			// 
			// textBox2
			// 
			textBox2.Location = new Point(549, 172);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(252, 27);
			textBox2.TabIndex = 9;
			// 
			// textBox1
			// 
			textBox1.BackColor = SystemColors.ButtonHighlight;
			textBox1.Location = new Point(549, 104);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(252, 27);
			textBox1.TabIndex = 8;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(473, 179);
			label2.Name = "label2";
			label2.Size = new Size(70, 20);
			label2.TabIndex = 7;
			label2.Text = "Password";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(468, 111);
			label1.Name = "label1";
			label1.Size = new Size(75, 20);
			label1.TabIndex = 6;
			label1.Text = "Username";
			// 
			// button1
			// 
			button1.Location = new Point(563, 241);
			button1.Margin = new Padding(2);
			button1.Name = "button1";
			button1.Size = new Size(92, 29);
			button1.TabIndex = 12;
			button1.Text = "Register";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// pictureBox1
			// 
			pictureBox1.BackgroundImage = Properties.Resources.loging;
			pictureBox1.Location = new Point(0, 0);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(467, 449);
			pictureBox1.TabIndex = 13;
			pictureBox1.TabStop = false;
			// 
			// Alllogin
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = SystemColors.ActiveCaption;
			ClientSize = new Size(800, 450);
			Controls.Add(pictureBox1);
			Controls.Add(button1);
			Controls.Add(button2);
			Controls.Add(adlog);
			Controls.Add(textBox2);
			Controls.Add(textBox1);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "Alllogin";
			Text = "Alllogin";
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button button2;
		private Button adlog;
		private TextBox textBox2;
		private TextBox textBox1;
		private Label label2;
		private Label label1;
		private Button button1;
		private PictureBox pictureBox1;
	}
}