﻿namespace csharpprojrctfinal
{
	partial class Buyermenu
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			button4 = new Button();
			button3 = new Button();
			button2 = new Button();
			button1 = new Button();
			SuspendLayout();
			// 
			// button4
			// 
			button4.Location = new Point(62, 238);
			button4.Name = "button4";
			button4.Size = new Size(131, 38);
			button4.TabIndex = 6;
			button4.Text = "REPORT";
			button4.UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			button3.Location = new Point(62, 145);
			button3.Name = "button3";
			button3.Size = new Size(131, 33);
			button3.TabIndex = 5;
			button3.Text = "SHOPING LIST";
			button3.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			button2.Location = new Point(62, 64);
			button2.Name = "button2";
			button2.Size = new Size(131, 29);
			button2.TabIndex = 4;
			button2.Text = "CARD";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// button1
			// 
			button1.Location = new Point(53, 409);
			button1.Name = "button1";
			button1.Size = new Size(164, 29);
			button1.TabIndex = 7;
			button1.Text = "Home Page";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// Buyermenu
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = SystemColors.ActiveCaption;
			ClientSize = new Size(800, 450);
			Controls.Add(button1);
			Controls.Add(button4);
			Controls.Add(button3);
			Controls.Add(button2);
			Name = "Buyermenu";
			StartPosition = FormStartPosition.CenterScreen;
			Text = "Buyermenu";
			ResumeLayout(false);
		}

		#endregion

		private Button button4;
		private Button button3;
		private Button button2;
		private Button button1;
	}
}