﻿namespace csharpprojrctfinal
{
	partial class Registration
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			textBox3 = new TextBox();
			textBox2 = new TextBox();
			textBox1 = new TextBox();
			button2 = new Button();
			button1 = new Button();
			label3 = new Label();
			label2 = new Label();
			label1 = new Label();
			comboBox1 = new ComboBox();
			textBox4 = new TextBox();
			label4 = new Label();
			pictureBox1 = new PictureBox();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			// 
			// textBox3
			// 
			textBox3.Location = new Point(485, 147);
			textBox3.Name = "textBox3";
			textBox3.Size = new Size(402, 27);
			textBox3.TabIndex = 26;
			// 
			// textBox2
			// 
			textBox2.Location = new Point(485, 74);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(402, 27);
			textBox2.TabIndex = 25;
			// 
			// textBox1
			// 
			textBox1.Location = new Point(485, 12);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(402, 27);
			textBox1.TabIndex = 24;
			// 
			// button2
			// 
			button2.Location = new Point(701, 452);
			button2.Name = "button2";
			button2.Size = new Size(186, 29);
			button2.TabIndex = 23;
			button2.Text = "Confrim Register ";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// button1
			// 
			button1.Location = new Point(520, 452);
			button1.Name = "button1";
			button1.Size = new Size(94, 29);
			button1.TabIndex = 22;
			button1.Text = "Back";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(415, 223);
			label3.Name = "label3";
			label3.Size = new Size(46, 20);
			label3.TabIndex = 21;
			label3.Text = "Email";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(409, 81);
			label2.Name = "label2";
			label2.Size = new Size(70, 20);
			label2.TabIndex = 20;
			label2.Text = "Password";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(406, 19);
			label1.Name = "label1";
			label1.Size = new Size(73, 20);
			label1.TabIndex = 19;
			label1.Text = "username";
			label1.Click += label1_Click;
			// 
			// comboBox1
			// 
			comboBox1.FormattingEnabled = true;
			comboBox1.Items.AddRange(new object[] { "Buyer", "Seller" });
			comboBox1.Location = new Point(596, 286);
			comboBox1.Margin = new Padding(2);
			comboBox1.Name = "comboBox1";
			comboBox1.Size = new Size(150, 28);
			comboBox1.TabIndex = 27;
			comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
			// 
			// textBox4
			// 
			textBox4.Location = new Point(485, 216);
			textBox4.Name = "textBox4";
			textBox4.Size = new Size(402, 27);
			textBox4.TabIndex = 28;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(412, 154);
			label4.Name = "label4";
			label4.Size = new Size(49, 20);
			label4.TabIndex = 29;
			label4.Text = "Name";
			// 
			// pictureBox1
			// 
			pictureBox1.BackgroundImage = Properties.Resources.regis;
			pictureBox1.Location = new Point(-1, 3);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(389, 491);
			pictureBox1.TabIndex = 30;
			pictureBox1.TabStop = false;
			// 
			// Registration
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = SystemColors.ActiveCaption;
			ClientSize = new Size(882, 493);
			Controls.Add(pictureBox1);
			Controls.Add(label4);
			Controls.Add(textBox4);
			Controls.Add(comboBox1);
			Controls.Add(textBox3);
			Controls.Add(textBox2);
			Controls.Add(textBox1);
			Controls.Add(button2);
			Controls.Add(button1);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Margin = new Padding(2);
			Name = "Registration";
			StartPosition = FormStartPosition.CenterScreen;
			Text = "Registration";
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private TextBox textBox3;
		private TextBox textBox2;
		private TextBox textBox1;
		private Button button2;
		private Button button1;
		private Label label3;
		private Label label2;
		private Label label1;
		private ComboBox comboBox1;
		private TextBox textBox4;
		private Label label4;
		private PictureBox pictureBox1;
	}
}