﻿namespace csharpprojrctfinal
{
	partial class sellerreg
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label4 = new Label();
			textBox4 = new TextBox();
			textBox3 = new TextBox();
			textBox2 = new TextBox();
			textBox1 = new TextBox();
			label3 = new Label();
			label2 = new Label();
			label1 = new Label();
			textBox5 = new TextBox();
			label5 = new Label();
			button2 = new Button();
			button1 = new Button();
			pictureBox1 = new PictureBox();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(398, 194);
			label4.Name = "label4";
			label4.Size = new Size(49, 20);
			label4.TabIndex = 37;
			label4.Text = "Name";
			// 
			// textBox4
			// 
			textBox4.Location = new Point(456, 187);
			textBox4.Name = "textBox4";
			textBox4.Size = new Size(341, 27);
			textBox4.TabIndex = 36;
			// 
			// textBox3
			// 
			textBox3.Location = new Point(456, 121);
			textBox3.Name = "textBox3";
			textBox3.Size = new Size(341, 27);
			textBox3.TabIndex = 35;
			// 
			// textBox2
			// 
			textBox2.Location = new Point(456, 69);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(341, 27);
			textBox2.TabIndex = 34;
			// 
			// textBox1
			// 
			textBox1.BackColor = SystemColors.Window;
			textBox1.Location = new Point(456, 17);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(341, 27);
			textBox1.TabIndex = 33;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(401, 128);
			label3.Name = "label3";
			label3.Size = new Size(46, 20);
			label3.TabIndex = 32;
			label3.Text = "Email";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(377, 72);
			label2.Name = "label2";
			label2.Size = new Size(70, 20);
			label2.TabIndex = 31;
			label2.Text = "Password";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(377, 24);
			label1.Name = "label1";
			label1.Size = new Size(73, 20);
			label1.TabIndex = 30;
			label1.Text = "username";
			// 
			// textBox5
			// 
			textBox5.Location = new Point(456, 257);
			textBox5.Name = "textBox5";
			textBox5.Size = new Size(341, 27);
			textBox5.TabIndex = 38;
			textBox5.TextChanged += textBox5_TextChanged;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(375, 264);
			label5.Name = "label5";
			label5.Size = new Size(75, 20);
			label5.TabIndex = 39;
			label5.Text = "Tradenum";
			// 
			// button2
			// 
			button2.Location = new Point(611, 409);
			button2.Name = "button2";
			button2.Size = new Size(186, 29);
			button2.TabIndex = 40;
			button2.Text = "Confrim Register ";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// button1
			// 
			button1.Location = new Point(443, 409);
			button1.Name = "button1";
			button1.Size = new Size(94, 29);
			button1.TabIndex = 41;
			button1.Text = "Back";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// pictureBox1
			// 
			pictureBox1.BackColor = SystemColors.ActiveCaption;
			pictureBox1.BackgroundImage = Properties.Resources.regis1;
			pictureBox1.Location = new Point(2, 12);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(374, 440);
			pictureBox1.TabIndex = 42;
			pictureBox1.TabStop = false;
			pictureBox1.Click += pictureBox1_Click;
			// 
			// sellerreg
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = SystemColors.ActiveCaption;
			ClientSize = new Size(800, 450);
			Controls.Add(pictureBox1);
			Controls.Add(button1);
			Controls.Add(button2);
			Controls.Add(label5);
			Controls.Add(textBox5);
			Controls.Add(label4);
			Controls.Add(textBox4);
			Controls.Add(textBox3);
			Controls.Add(textBox2);
			Controls.Add(textBox1);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "sellerreg";
			Text = "sellerreg";
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label4;
		private TextBox textBox4;
		private TextBox textBox3;
		private TextBox textBox2;
		private TextBox textBox1;
		private Label label3;
		private Label label2;
		private Label label1;
		private TextBox textBox5;
		private Label label5;
		private Button button2;
		private Button button1;
		private PictureBox pictureBox1;
	}
}